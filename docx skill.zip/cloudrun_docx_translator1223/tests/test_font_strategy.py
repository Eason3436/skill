import importlib.util
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

from lxml import etree


WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": WORD_NS}


def load_translator_module():
    module_path = Path(r"C:\Users\eason\Desktop\docx skill\cloudrun_docx_translator1223\translator.py")
    spec = importlib.util.spec_from_file_location("docx_skill_tool_test", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load translator module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


TRANSLATOR = load_translator_module()


def build_minimal_docx(
    output_path: Path,
    *,
    source_text: str,
    run_ascii_font: str,
    run_eastasia_font: str,
    style_ascii_font: str,
    style_eastasia_font: str,
) -> None:
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>
"""
    package_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>
"""
    document_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>
"""
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{WORD_NS}">
  <w:body>
    <w:p>
      <w:pPr>
        <w:pStyle w:val="Title"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="{run_ascii_font}" w:hAnsi="{run_ascii_font}" w:eastAsia="{run_eastasia_font}"/>
        </w:rPr>
        <w:t xml:space="preserve">{source_text}</w:t>
      </w:r>
    </w:p>
    <w:sectPr>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>
"""
    styles_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="{WORD_NS}">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr>
      <w:rFonts w:ascii="{style_ascii_font}" w:hAnsi="{style_ascii_font}" w:eastAsia="{style_eastasia_font}"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:basedOn w:val="Normal"/>
    <w:rPr>
      <w:rFonts w:ascii="{style_ascii_font}" w:hAnsi="{style_ascii_font}" w:eastAsia="{style_eastasia_font}"/>
    </w:rPr>
  </w:style>
</w:styles>
"""

    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", package_rels)
        archive.writestr("word/document.xml", document_xml)
        archive.writestr("word/styles.xml", styles_xml)
        archive.writestr("word/_rels/document.xml.rels", document_rels)


def read_docx_xml(docx_path: Path, part_name: str) -> etree._Element:
    with zipfile.ZipFile(docx_path) as archive:
        return etree.fromstring(archive.read(part_name))


class FontStrategyRegressionTests(unittest.TestCase):
    def run_case(
        self,
        *,
        source_text: str,
        translated_text: str,
        target_lang: str,
        run_font: str,
        style_font: str,
    ):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            input_docx = root / "input.docx"
            workspace = root / "workspace"
            output_docx = root / "output.docx"
            translations_path = workspace / "translations.json"

            build_minimal_docx(
                input_docx,
                source_text=source_text,
                run_ascii_font="Times New Roman",
                run_eastasia_font=run_font,
                style_ascii_font="Calibri",
                style_eastasia_font=style_font,
            )

            TRANSLATOR.extract_docx_to_workspace(input_docx, workspace)
            report = TRANSLATOR.validate_workspace(workspace, target_lang=target_lang)

            segments = TRANSLATOR.read_json(workspace / "segments.json")
            self.assertIsInstance(segments, list)
            translations = {segments[0]["id"]: translated_text}
            TRANSLATOR.write_json(translations_path, translations)

            summary = TRANSLATOR.apply_translations_from_workspace(
                workspace,
                translations_path,
                output_docx,
                target_lang=target_lang,
            )

            document_root = read_docx_xml(output_docx, "word/document.xml")
            styles_root = read_docx_xml(output_docx, "word/styles.xml")
            return report, summary, document_root, styles_root

    def test_english_template_to_traditional_chinese_repairs_run_and_style_fonts(self):
        report, summary, document_root, styles_root = self.run_case(
            source_text="DELUXE SCORE",
            translated_text="返校交通車",
            target_lang="zh-Hant",
            run_font="Times New Roman",
            style_font="Calibri",
        )

        font_report = report["font_compatibility"]
        self.assertGreaterEqual(font_report["suspicious_run_font_count"], 1)
        self.assertGreaterEqual(font_report["suspicious_style_font_count"], 1)

        text = "".join(node.text or "" for node in document_root.findall(".//w:t", NS))
        self.assertIn("返校交通車", text)

        run_rfonts = document_root.find(".//w:r/w:rPr/w:rFonts", NS)
        self.assertIsNotNone(run_rfonts)
        self.assertEqual(run_rfonts.get(f"{{{WORD_NS}}}eastAsia"), "Microsoft JhengHei")

        title_style = styles_root.find(".//w:style[@w:styleId='Title']/w:rPr/w:rFonts", NS)
        self.assertIsNotNone(title_style)
        self.assertEqual(title_style.get(f"{{{WORD_NS}}}eastAsia"), "Microsoft JhengHei")
        self.assertEqual(summary["run_font_updates"], 1)
        self.assertGreaterEqual(summary["style_font_updates"], 1)

    def test_english_template_to_simplified_chinese_repairs_run_and_style_fonts(self):
        report, summary, document_root, styles_root = self.run_case(
            source_text="MOREDOUGH SHUTTLE",
            translated_text="返校班车",
            target_lang="zh-Hans",
            run_font="Arial",
            style_font="Times New Roman",
        )

        font_report = report["font_compatibility"]
        self.assertGreaterEqual(font_report["suspicious_run_font_count"], 1)
        self.assertGreaterEqual(font_report["suspicious_style_font_count"], 1)

        text = "".join(node.text or "" for node in document_root.findall(".//w:t", NS))
        self.assertIn("返校班车", text)

        run_rfonts = document_root.find(".//w:r/w:rPr/w:rFonts", NS)
        self.assertIsNotNone(run_rfonts)
        self.assertEqual(run_rfonts.get(f"{{{WORD_NS}}}eastAsia"), "Microsoft YaHei")

        title_style = styles_root.find(".//w:style[@w:styleId='Title']/w:rPr/w:rFonts", NS)
        self.assertIsNotNone(title_style)
        self.assertEqual(title_style.get(f"{{{WORD_NS}}}eastAsia"), "Microsoft YaHei")
        self.assertEqual(summary["run_font_updates"], 1)
        self.assertGreaterEqual(summary["style_font_updates"], 1)

    def test_chinese_template_to_english_keeps_existing_cjk_fonts_unchanged(self):
        report, summary, document_root, styles_root = self.run_case(
            source_text="返校交通車",
            translated_text="School Shuttle",
            target_lang="en",
            run_font="Microsoft JhengHei",
            style_font="Microsoft JhengHei",
        )

        font_report = report["font_compatibility"]
        self.assertFalse(font_report["cjk_target"])
        self.assertEqual(font_report["suspicious_run_font_count"], 0)
        self.assertEqual(font_report["suspicious_style_font_count"], 0)

        text = "".join(node.text or "" for node in document_root.findall(".//w:t", NS))
        self.assertIn("School Shuttle", text)

        run_rfonts = document_root.find(".//w:r/w:rPr/w:rFonts", NS)
        self.assertIsNotNone(run_rfonts)
        self.assertEqual(run_rfonts.get(f"{{{WORD_NS}}}eastAsia"), "Microsoft JhengHei")

        title_style = styles_root.find(".//w:style[@w:styleId='Title']/w:rPr/w:rFonts", NS)
        self.assertIsNotNone(title_style)
        self.assertEqual(title_style.get(f"{{{WORD_NS}}}eastAsia"), "Microsoft JhengHei")
        self.assertEqual(summary["run_font_updates"], 0)
        self.assertEqual(summary["style_font_updates"], 0)


if __name__ == "__main__":
    unittest.main()
