---
name: docx-word-translator
description: Translate Microsoft Word `.docx` files while preserving Word layout and structure. Use this whenever the user wants to translate a Word document, DOCX report, manual, proposal, spec sheet, or other `.docx` content into another language and keeping tables, text boxes, comments, and formatting matters. Use it even if the user just says "translate this Word file" or "make this report Chinese" without explicitly mentioning a skill.
---

# DOCX Word Translator

This skill is local and model-native:

- The bundled script only extracts text from `.docx`, batches it, and writes translations back.
- The translation itself should be done by the current Codex model in the conversation.
- Do not call OpenAI, Vertex, Azure, OpenRouter, Flask, FastAPI, ngrok, or any HTTP translation service from this skill.

## When To Use

- The user wants an existing `.docx` translated into another language.
- Preserving Word formatting and structure matters.
- The file contains tables, text boxes, comments, or mixed layout that plain copy-paste would damage.

## When Not To Use

- The input is not `.docx`.
- The user wants writing or rewriting rather than document translation.
- The user explicitly asks for a web API or hosted translation service.

## Core Workflow

1. Run `extract` to create a workspace from the source `.docx`.
2. Run `validate` and inspect `quality-report.json` before translating anything.
3. If the quality report shows suspicious merged segments, stop and fix extraction before continuing.
4. Run `chunk` to produce model-sized translation batches.
5. Translate the batch items yourself in-chat using the current model.
6. Save the translated results as `translations.json`.
7. Run `apply` to rebuild the translated `.docx`.

Run these steps sequentially. Do not start `chunk` before `extract` has finished writing `segments.json`.
For `zh-Hant`, `zh-Hans`, `ja`, and `ko`, always pass `--target-lang` to `validate` and `apply` so the skill can inspect and repair East Asian font bindings safely.

## Commands

Extract:

```powershell
python "<skill-dir>\scripts\translate_docx.py" extract "C:\path\input.docx" --workspace "C:\path\docx-work"
```

Validate extracted segments and font compatibility:

```powershell
python "<skill-dir>\scripts\translate_docx.py" validate --workspace "C:\path\docx-work" --target-lang zh-Hant
```

Create batches:

```powershell
python "<skill-dir>\scripts\translate_docx.py" chunk --workspace "C:\path\docx-work" --max-chars 6000 --max-items 40
```

Apply translations:

```powershell
python "<skill-dir>\scripts\translate_docx.py" apply --workspace "C:\path\docx-work" --translations "C:\path\docx-work\translations.json" --output "C:\path\translated.docx" --target-lang zh-Hant
```

Inspect workspace:

```powershell
python "<skill-dir>\scripts\translate_docx.py" inspect --workspace "C:\path\docx-work"
```

## Translation Rules

- Translate only the `text` field values.
- Preserve every `id` exactly.
- Return the same number of items you received.
- Keep numbers, units, codes, placeholders, URLs, file paths, and model names unchanged unless they clearly require translation.
- Preserve list order.
- Do the translation in the current conversation model. Do not write a separate bulk-translation script to bypass the batch workflow.
- Do not install transliteration or translation libraries as a shortcut for the translation step.
- If `quality-report.json` flags suspicious merged segments, do not translate yet.
- For CJK output languages, pass `--target-lang` so the tool can inspect and repair `w:rFonts/@w:eastAsia` when needed.

## `translations.json` Formats

Object form:

```json
{
  "word/document.xml::0": "Translated text for the first segment",
  "word/document.xml::1": "Translated text for the second segment"
}
```

List form:

```json
[
  { "id": "word/document.xml::0", "text": "Translated text for the first segment" },
  { "id": "word/document.xml::1", "text": "Translated text for the second segment" }
]
```

## Batch Translation Guidance

Each batch in `batches.json` looks like this:

```json
{
  "batch_id": 0,
  "char_count": 4210,
  "items": [
    { "id": "word/document.xml::0", "text": "..." }
  ]
}
```

When translating a batch:

1. Read `items`.
2. Translate each `text`.
3. Output JSON in the same order.
4. Do not add commentary around the JSON.

If the document is large, translate one batch at a time and merge all outputs into one `translations.json`.

## Quality Gate

`validate` writes `quality-report.json`. Review it before translating.

If it shows suspicious merged segments, especially:

- very long segments
- repeated table headers
- many timestamps inside one segment
- multiple route headers inside one segment

then the extraction quality is not good enough yet. Fix the extractor or rerun extraction before translating. Do not push forward with translation anyway, because that usually breaks tables or mixed-layout documents.

If `font_compatibility` shows suspicious run or style font bindings such as:

- `eastAsia_font_incompatible`
- `missing_eastAsia_with_latin_font`

then the document is at risk of showing tofu or square boxes after translation into a CJK language.

## Font Strategy

When `--target-lang` is a CJK target, `apply` uses a conservative font policy:

- `zh-Hant`: prefer `Microsoft JhengHei`, while leaving existing `PMingLiU`-style traditional Chinese fonts alone
- `zh-Hans`: prefer `Microsoft YaHei`, while leaving existing `SimSun`-style simplified Chinese fonts alone
- `ja`: prefer `Yu Gothic`
- `ko`: prefer `Malgun Gothic`

The tool only repairs fonts when necessary:

- the translated text actually contains CJK characters
- and the run has no `eastAsia` font, or it is explicitly bound to a Latin font such as `Times New Roman`, `Arial`, or `Calibri`
- style-level repairs only touch styles whose `eastAsia` font is explicitly incompatible

This avoids flattening the entire document into one font and leaves English-only branding or Latin text alone.

## Files In The Workspace

- `manifest.json`: workspace summary
- `segments.json`: all extracted segments
- `quality-report.json`: extraction quality report and suspicious segment warnings
- `batches.json`: chunked translation batches
- `translations.template.json`: empty placeholder file
- `apply-result.json`: summary after rebuilding the final `.docx`

JSON workspace files are written as UTF-8 with BOM so they display correctly in common Windows editors and shells.

If needed, read `references/workspace-format.md`.
