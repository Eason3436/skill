#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import logging
import os
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

from lxml import etree


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


LOGGER = logging.getLogger("docx_skill_tool")
if not LOGGER.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOGGER.addHandler(handler)
LOGGER.setLevel(logging.INFO)
LOGGER.propagate = False


WORDPROCESSING_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
DRAWING_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
MATH_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
RELATIONSHIP_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
XML_NS = "http://www.w3.org/XML/1998/namespace"

DOCX_NAMESPACES: Dict[str, str] = {
    "w": WORDPROCESSING_NS,
    "a": DRAWING_NS,
    "m": MATH_NS,
    "r": RELATIONSHIP_NS,
    "v": "urn:schemas-microsoft-com:vml",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    "wpg": "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
    "o": "urn:schemas-microsoft-com:office:office",
    "w10": "urn:schemas-microsoft-com:office:word",
}

for prefix, uri in DOCX_NAMESPACES.items():
    etree.register_namespace(prefix, uri)

MARKUP_COMPAT_NS = DOCX_NAMESPACES["mc"]

TEXT_TAGS = {
    f"{{{WORDPROCESSING_NS}}}t",
    f"{{{WORDPROCESSING_NS}}}delText",
    f"{{{DRAWING_NS}}}t",
}
IGNORED_TEXT_TAGS = {
    f"{{{WORDPROCESSING_NS}}}instrText",
}
PARAGRAPH_TAGS = {
    f"{{{WORDPROCESSING_NS}}}p",
    f"{{{DRAWING_NS}}}p",
}


XML10_OK = lambda c: (  # noqa: E731
    c in "\t\r\n"
    or (0x20 <= ord(c) <= 0xD7FF)
    or (0xE000 <= ord(c) <= 0xFFFD)
    or (0x10000 <= ord(c) <= 0x10FFFF)
)

DEFAULT_SEGMENT_WARNING_CHARS = 800
TIME_MARKER_RE = re.compile(r"\b\d{2}:\d{2}\b")
QUALITY_HEADER_TOKENS = ("站名", "時間", "候車地點")
HAN_TEXT_RE = re.compile(r"[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]")
JA_TEXT_RE = re.compile(r"[\u3040-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]")
KO_TEXT_RE = re.compile(r"[\u1100-\u11FF\u3130-\u318F\uAC00-\uD7AF]")
LATIN_FONT_KEYWORDS = (
    "arial",
    "aptos",
    "bahnschrift",
    "calibri",
    "cambria",
    "candara",
    "consolas",
    "courier",
    "franklin",
    "garamond",
    "georgia",
    "helvetica",
    "segoe",
    "tahoma",
    "times",
    "trebuchet",
    "verdana",
)
TARGET_FONT_POLICIES: Dict[str, Dict[str, object]] = {
    "zh-hant": {
        "primary": "Microsoft JhengHei",
        "alternates": ("Microsoft JhengHei", "微軟正黑體", "PMingLiU", "新細明體"),
    },
    "zh-hans": {
        "primary": "Microsoft YaHei",
        "alternates": ("Microsoft YaHei", "微软雅黑", "SimSun", "宋体"),
    },
    "ja": {
        "primary": "Yu Gothic",
        "alternates": ("Yu Gothic", "游ゴシック"),
    },
    "ko": {
        "primary": "Malgun Gothic",
        "alternates": ("Malgun Gothic", "맑은 고딕"),
    },
}
RISKY_STYLE_NAME_TOKENS = (
    "body",
    "emphasis",
    "heading",
    "normal",
    "quote",
    "subtitle",
    "title",
)


@dataclass
class XmlSegment:
    segment_id: str
    part_name: str
    index: int
    text: str
    text_nodes: List[etree._Element]


def sanitize_xml_text(text: str) -> str:
    value = (text or "").replace("\r", "").replace("\n", "")
    return "".join(ch for ch in value if XML10_OK(ch))


def xml_attr(name: str) -> str:
    return f"{{{WORDPROCESSING_NS}}}{name}"


def xml_tag(name: str) -> str:
    return f"{{{WORDPROCESSING_NS}}}{name}"


def get_word_value(element: Optional[etree._Element], name: str) -> Optional[str]:
    if element is None:
        return None
    return element.get(xml_attr(name)) or element.get(name)


def set_word_value(element: etree._Element, name: str, value: str) -> None:
    element.set(xml_attr(name), value)


def normalize_target_lang(target_lang: Optional[str]) -> Optional[str]:
    if not target_lang:
        return None

    value = target_lang.strip().lower().replace("_", "-")
    if not value:
        return None
    if value.startswith("zh-hant") or value in {"zh-tw", "zh-hk", "zh-mo"}:
        return "zh-hant"
    if value.startswith("zh-hans") or value in {"zh-cn", "zh-sg"}:
        return "zh-hans"
    if value.startswith("ja"):
        return "ja"
    if value.startswith("ko"):
        return "ko"
    if value.startswith("en"):
        return "en"
    return value


def get_target_font_policy(target_lang: Optional[str]) -> Optional[Dict[str, object]]:
    normalized = normalize_target_lang(target_lang)
    if normalized is None:
        return None
    return TARGET_FONT_POLICIES.get(normalized)


def normalize_font_name(font_name: Optional[str]) -> str:
    value = (font_name or "").strip().casefold()
    return re.sub(r"[\s_-]+", "", value)


def font_looks_latin(font_name: Optional[str]) -> bool:
    normalized = normalize_font_name(font_name)
    if not normalized:
        return False
    return any(keyword in normalized for keyword in LATIN_FONT_KEYWORDS)


def font_is_acceptable_for_target(font_name: Optional[str], target_lang: Optional[str]) -> bool:
    if not font_name:
        return False
    policy = get_target_font_policy(target_lang)
    if policy is None:
        return True
    allowed = {normalize_font_name(item) for item in policy["alternates"]}  # type: ignore[index]
    return normalize_font_name(font_name) in allowed


def font_is_unsuitable_for_target(font_name: Optional[str], target_lang: Optional[str]) -> bool:
    if not font_name:
        return False
    if font_is_acceptable_for_target(font_name, target_lang):
        return False
    return font_looks_latin(font_name)


def is_cjk_target(target_lang: Optional[str]) -> bool:
    return get_target_font_policy(target_lang) is not None


def text_contains_target_script(text: str, target_lang: Optional[str]) -> bool:
    normalized = normalize_target_lang(target_lang)
    if normalized == "zh-hant" or normalized == "zh-hans":
        return bool(HAN_TEXT_RE.search(text))
    if normalized == "ja":
        return bool(JA_TEXT_RE.search(text))
    if normalized == "ko":
        return bool(KO_TEXT_RE.search(text))
    return False


def ensure_word_child(parent: etree._Element, name: str) -> etree._Element:
    child = parent.find(f"w:{name}", namespaces=DOCX_NAMESPACES)
    if child is not None:
        return child
    child = etree.Element(xml_tag(name))
    parent.insert(0, child)
    return child


def get_run_font_values(run_or_props: etree._Element) -> Dict[str, Optional[str]]:
    if safe_tag(run_or_props) == xml_tag("r"):
        r_pr = run_or_props.find("w:rPr", namespaces=DOCX_NAMESPACES)
    else:
        r_pr = run_or_props
    if r_pr is None:
        return {"ascii": None, "hAnsi": None, "eastAsia": None, "cs": None}

    r_fonts = r_pr.find("w:rFonts", namespaces=DOCX_NAMESPACES)
    if r_fonts is None:
        return {"ascii": None, "hAnsi": None, "eastAsia": None, "cs": None}

    return {
        "ascii": get_word_value(r_fonts, "ascii"),
        "hAnsi": get_word_value(r_fonts, "hAnsi"),
        "eastAsia": get_word_value(r_fonts, "eastAsia"),
        "cs": get_word_value(r_fonts, "cs"),
    }


def style_identity(style: etree._Element) -> Tuple[str, str]:
    style_id = get_word_value(style, "styleId") or ""
    name_node = style.find("w:name", namespaces=DOCX_NAMESPACES)
    style_name = get_word_value(name_node, "val") or style_id
    return style_id, style_name


def style_is_font_risk(style_id: str, style_name: str) -> bool:
    joined = f"{style_id} {style_name}".casefold()
    return any(token in joined for token in RISKY_STYLE_NAME_TOKENS)


def increment_counter(counter: Dict[str, int], key: Optional[str]) -> None:
    if not key:
        return
    counter[key] = counter.get(key, 0) + 1


def summarize_font_counter(counter: Dict[str, int]) -> List[Dict[str, object]]:
    return [
        {"font": font, "count": count}
        for font, count in sorted(counter.items(), key=lambda item: (-item[1], item[0]))[:20]
    ]


def extract_run_text(run: etree._Element) -> str:
    parts: List[str] = []
    for node in run.iter():
        if safe_tag(node) in TEXT_TAGS:
            parts.append(node.text or "")
    return "".join(parts)
def safe_tag(element: etree._Element) -> str:
    try:
        tag = element.tag
    except Exception:
        return ""
    return tag if isinstance(tag, str) else ""


def ensure_clean_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def iter_docx_parts(unpacked_dir: Path, include_comments: bool) -> Iterator[Tuple[str, Path]]:
    word_dir = unpacked_dir / "word"
    if not word_dir.exists():
        return
    for file_path in sorted(word_dir.rglob("*")):
        if not file_path.is_file():
            continue
        rel = file_path.relative_to(unpacked_dir).as_posix()
        if rel.endswith(".rels"):
            continue
        if not include_comments and rel.endswith("comments.xml"):
            continue
        if rel.endswith((".xml", ".vml")):
            yield rel, file_path


class DocxStructureHelper:
    def __init__(self) -> None:
        self.parent_map: Dict[etree._Element, etree._Element] = {}
        self.nearest_paragraph_cache: Dict[etree._Element, Optional[etree._Element]] = {}
        self.fallback_cache: Dict[etree._Element, bool] = {}

    def collect_segments_from_file(self, part_name: str, xml_path: Path) -> Tuple[etree._ElementTree, List[XmlSegment]]:
        parser = etree.XMLParser(recover=False, huge_tree=True)
        root = etree.parse(str(xml_path), parser=parser).getroot()
        tree = etree.ElementTree(root)
        self.parent_map = {child: parent for parent in root.iter() for child in parent}
        self.nearest_paragraph_cache = {}
        self.fallback_cache = {}

        segments: List[XmlSegment] = []
        index = 0
        for element in root.iter():
            if safe_tag(element) not in PARAGRAPH_TAGS:
                continue
            text_nodes = list(self.iter_text_nodes(element))
            if not text_nodes:
                continue
            text = "".join(node.text or "" for node in text_nodes)
            if not text.strip():
                continue
            segment_id = f"{part_name}::{index}"
            segments.append(
                XmlSegment(
                    segment_id=segment_id,
                    part_name=part_name,
                    index=index,
                    text=text,
                    text_nodes=text_nodes,
                )
            )
            index += 1
        return tree, segments

    def iter_text_nodes(self, element: etree._Element) -> Iterator[etree._Element]:
        for node in element.iter():
            tag = safe_tag(node)
            if not tag:
                continue
            if tag in IGNORED_TEXT_TAGS:
                continue
            if tag.startswith(f"{{{MATH_NS}}}") or tag.startswith(f"{{{RELATIONSHIP_NS}}}"):
                continue
            if tag in TEXT_TAGS and self.nearest_paragraph(node) is element and not self.is_in_fallback(node):
                yield node

    def nearest_paragraph(self, node: etree._Element) -> Optional[etree._Element]:
        cached = self.nearest_paragraph_cache.get(node)
        if cached is not None or node in self.nearest_paragraph_cache:
            return cached

        current = self.parent_map.get(node)
        while current is not None:
            if safe_tag(current) in PARAGRAPH_TAGS:
                self.nearest_paragraph_cache[node] = current
                return current
            current = self.parent_map.get(current)

        self.nearest_paragraph_cache[node] = None
        return None

    def is_in_fallback(self, node: etree._Element) -> bool:
        cached = self.fallback_cache.get(node)
        if cached is not None or node in self.fallback_cache:
            return cached

        current = self.parent_map.get(node)
        while current is not None:
            if safe_tag(current) == f"{{{MARKUP_COMPAT_NS}}}Fallback":
                self.fallback_cache[node] = True
                return True
            current = self.parent_map.get(current)

        self.fallback_cache[node] = False
        return False

    def apply_translation(self, segment: XmlSegment, translated_text: str, target_lang: Optional[str] = None) -> Dict[str, int]:
        translated = sanitize_xml_text(translated_text)
        if not segment.text_nodes:
            return {"run_font_updates": 0}

        candidates = []
        total_by_color: Dict[str, int] = {}
        size_values: List[int] = []

        for node in segment.text_nodes:
            original = node.text or ""
            run = self.find_run(node)
            size_val, color_val, is_super_sub, is_reference = self.run_props(run)
            stripped = original.strip()
            is_marker = stripped.isdigit() and len(stripped) <= 3 and len(original) <= 4
            protected = is_super_sub or is_reference or is_marker
            candidates.append(
                {
                    "node": node,
                    "original": original,
                    "length": len(original),
                    "size": size_val,
                    "color": color_val,
                    "protected": protected,
                }
            )
            if protected:
                continue
            key = color_val or "__inherit__"
            total_by_color[key] = total_by_color.get(key, 0) + max(1, len(original))
            if size_val is not None:
                size_values.append(size_val)

        dominant_color = None
        if total_by_color:
            dominant_color = max(total_by_color.items(), key=lambda item: item[1])[0]
        dominant_size = max(size_values) if size_values else None

        prefix = ""
        for candidate in candidates:
            original = candidate["original"]
            if candidate["protected"] and original.strip():
                prefix += original
                continue
            if original and not original.strip():
                continue
            break

        if prefix.strip():
            stripped_prefix = prefix.strip()
            current = translated.lstrip()
            if current.startswith(stripped_prefix):
                current = current[len(stripped_prefix):].lstrip()
            translated = current

        anchor_index = self.choose_anchor_index(candidates, dominant_color, dominant_size)
        if anchor_index is None:
            anchor_index = max(range(len(candidates)), key=lambda idx: int(candidates[idx]["length"]))

        anchor_run: Optional[etree._Element] = None
        for index, candidate in enumerate(candidates):
            node = candidate["node"]
            node.set(f"{{{XML_NS}}}space", "preserve")
            if candidate["protected"]:
                continue
            if index == anchor_index:
                node.text = translated
                anchor_run = self.find_run(node)
            else:
                node.text = ""

        run_font_updates = 1 if self.ensure_target_run_font(anchor_run, translated, target_lang) else 0
        return {"run_font_updates": run_font_updates}

    def find_run(self, node: etree._Element) -> Optional[etree._Element]:
        current = node
        for _ in range(8):
            parent = self.parent_map.get(current)
            if parent is None:
                return None
            if parent.tag == f"{{{WORDPROCESSING_NS}}}r":
                return parent
            current = parent
        return None

    def run_props(
        self,
        run: Optional[etree._Element],
    ) -> Tuple[Optional[int], Optional[str], bool, bool]:
        if run is None:
            return None, None, False, False
        properties = run.find("w:rPr", namespaces=DOCX_NAMESPACES)
        if properties is None:
            return None, None, False, False

        size = None
        size_node = properties.find("w:sz", namespaces=DOCX_NAMESPACES)
        if size_node is not None:
            value = size_node.get(xml_attr("val")) or size_node.get("val")
            if value and value.isdigit():
                size = int(value)

        color = None
        color_node = properties.find("w:color", namespaces=DOCX_NAMESPACES)
        if color_node is not None:
            value = color_node.get(xml_attr("val")) or color_node.get("val")
            if value and value.lower() != "auto":
                color = value

        is_super_sub = False
        align_node = properties.find("w:vertAlign", namespaces=DOCX_NAMESPACES)
        if align_node is not None:
            value = (align_node.get(xml_attr("val")) or align_node.get("val") or "").lower()
            is_super_sub = value in {"superscript", "subscript"}

        is_reference = False
        style_node = properties.find("w:rStyle", namespaces=DOCX_NAMESPACES)
        if style_node is not None:
            value = style_node.get(xml_attr("val")) or style_node.get("val") or ""
            is_reference = "FootnoteReference" in value or "EndnoteReference" in value

        return size, color, is_super_sub, is_reference

    def choose_anchor_index(
        self,
        candidates: Sequence[Dict[str, object]],
        dominant_color: Optional[str],
        dominant_size: Optional[int],
    ) -> Optional[int]:
        best_index = None
        best_score = -10**12
        for index, candidate in enumerate(candidates):
            if candidate["protected"]:
                continue
            score = int(candidate["length"]) * 10
            size = candidate["size"]
            color = candidate["color"] or "__inherit__"
            if isinstance(size, int):
                score += size
                if dominant_size and size < int(dominant_size * 0.75):
                    score -= 200
            if dominant_color and color == dominant_color:
                score += 100
            if score > best_score:
                best_index = index
                best_score = score
        return best_index

    def ensure_target_run_font(
        self,
        run: Optional[etree._Element],
        translated_text: str,
        target_lang: Optional[str],
    ) -> bool:
        policy = get_target_font_policy(target_lang)
        if run is None or policy is None:
            return False
        if not text_contains_target_script(translated_text, target_lang):
            return False

        r_pr = ensure_word_child(run, "rPr")
        r_fonts = ensure_word_child(r_pr, "rFonts")
        east_asia_font = get_word_value(r_fonts, "eastAsia")
        if east_asia_font and not font_is_unsuitable_for_target(east_asia_font, target_lang):
            return False

        set_word_value(r_fonts, "eastAsia", str(policy["primary"]))
        return True


def workspace_file(workspace_dir: Path, name: str) -> Path:
    return workspace_dir / name


def write_json(path: Path, payload: object) -> None:
    # Use UTF-8 with BOM so Windows tools that default to ANSI still display CJK text correctly.
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8-sig")


def read_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def text_excerpt(text: str, limit: int = 160) -> str:
    compact = re.sub(r"\s+", " ", text).strip()
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3] + "..."


def analyze_segments(
    segments_payload: Sequence[Dict[str, object]],
    *,
    warning_chars: int = DEFAULT_SEGMENT_WARNING_CHARS,
) -> Dict[str, object]:
    suspicious_segments: List[Dict[str, object]] = []
    max_segment_chars = 0

    for item in segments_payload:
        text = str(item.get("text", ""))
        char_count = len(text)
        max_segment_chars = max(max_segment_chars, char_count)
        reasons: List[str] = []

        if char_count >= warning_chars:
            reasons.append("very_long_segment")
        if len(TIME_MARKER_RE.findall(text)) >= 4:
            reasons.append("many_timestamps")
        if text.count("號車(") >= 2:
            reasons.append("multiple_route_headers")
        header_hits = sum(text.count(token) for token in QUALITY_HEADER_TOKENS)
        if header_hits >= 4:
            reasons.append("repeated_table_headers")

        if reasons:
            suspicious_segments.append(
                {
                    "id": str(item.get("id", "")),
                    "part": str(item.get("part", "")),
                    "index": int(item.get("index", 0)),
                    "char_count": char_count,
                    "reasons": reasons,
                    "text_excerpt": text_excerpt(text),
                }
            )

    return {
        "segment_count": len(segments_payload),
        "max_segment_chars": max_segment_chars,
        "warning_chars": warning_chars,
        "suspicious_segment_count": len(suspicious_segments),
        "suspicious_segments": suspicious_segments[:25],
    }


def analyze_font_compatibility(
    unpacked_dir: Path,
    *,
    include_comments: bool,
    target_lang: Optional[str],
) -> Optional[Dict[str, object]]:
    normalized = normalize_target_lang(target_lang)
    policy = get_target_font_policy(normalized)
    if normalized is None:
        return None

    run_font_counter: Dict[str, int] = {}
    style_font_counter: Dict[str, int] = {}
    run_warnings: List[Dict[str, object]] = []
    style_warnings: List[Dict[str, object]] = []

    helper = DocxStructureHelper()
    for part_name, xml_path in iter_docx_parts(unpacked_dir, include_comments=include_comments):
        if part_name.endswith("styles.xml"):
            continue
        _tree, segments = helper.collect_segments_from_file(part_name, xml_path)
        seen_runs: set[int] = set()
        for segment in segments:
            for node in segment.text_nodes:
                run = helper.find_run(node)
                if run is None or id(run) in seen_runs:
                    continue
                seen_runs.add(id(run))
                font_values = get_run_font_values(run)
                east_asia_font = font_values["eastAsia"]
                ascii_font = font_values["ascii"] or font_values["hAnsi"]
                increment_counter(run_font_counter, east_asia_font)

                reason = None
                if east_asia_font and font_is_unsuitable_for_target(east_asia_font, normalized):
                    reason = "eastAsia_font_incompatible"
                elif policy and not east_asia_font and font_looks_latin(ascii_font):
                    reason = "missing_eastAsia_with_latin_font"

                if reason:
                    run_warnings.append(
                        {
                            "part": part_name,
                            "segment_id": segment.segment_id,
                            "text_excerpt": text_excerpt(extract_run_text(run)),
                            "ascii": font_values["ascii"],
                            "hAnsi": font_values["hAnsi"],
                            "eastAsia": east_asia_font,
                            "reason": reason,
                        }
                    )

    styles_path = unpacked_dir / "word" / "styles.xml"
    if styles_path.exists():
        parser = etree.XMLParser(recover=False, huge_tree=True)
        styles_root = etree.parse(str(styles_path), parser=parser).getroot()
        for style in styles_root.findall("w:style", namespaces=DOCX_NAMESPACES):
            style_id, style_name = style_identity(style)
            r_pr = style.find("w:rPr", namespaces=DOCX_NAMESPACES)
            font_values = get_run_font_values(r_pr) if r_pr is not None else {"ascii": None, "hAnsi": None, "eastAsia": None, "cs": None}
            east_asia_font = font_values["eastAsia"]
            ascii_font = font_values["ascii"] or font_values["hAnsi"]
            increment_counter(style_font_counter, east_asia_font)

            reason = None
            if east_asia_font and font_is_unsuitable_for_target(east_asia_font, normalized):
                reason = "eastAsia_font_incompatible"
            elif policy and style_is_font_risk(style_id, style_name) and not east_asia_font and font_looks_latin(ascii_font):
                reason = "missing_eastAsia_with_latin_font"

            if reason:
                style_warnings.append(
                    {
                        "style_id": style_id,
                        "style_name": style_name,
                        "ascii": font_values["ascii"],
                        "hAnsi": font_values["hAnsi"],
                        "eastAsia": east_asia_font,
                        "reason": reason,
                    }
                )

    return {
        "target_lang": normalized,
        "cjk_target": policy is not None,
        "preferred_eastAsia_font": None if policy is None else str(policy["primary"]),
        "explicit_run_eastAsia_fonts": summarize_font_counter(run_font_counter),
        "explicit_style_eastAsia_fonts": summarize_font_counter(style_font_counter),
        "suspicious_run_font_count": len(run_warnings),
        "suspicious_style_font_count": len(style_warnings),
        "run_warnings": run_warnings[:25],
        "style_warnings": style_warnings[:25],
    }


def validate_workspace(workspace_dir: Path, target_lang: Optional[str] = None) -> Dict[str, object]:
    segments = read_json(workspace_file(workspace_dir, "segments.json"))
    if not isinstance(segments, list):
        raise ValueError("segments.json must contain a list")
    report = analyze_segments(segments)
    manifest = read_json(workspace_file(workspace_dir, "manifest.json"))
    include_comments = True
    if isinstance(manifest, dict):
        include_comments = bool(manifest.get("include_comments", True))
    font_compatibility = analyze_font_compatibility(
        workspace_dir / "unpacked",
        include_comments=include_comments,
        target_lang=target_lang,
    )
    report["target_lang"] = normalize_target_lang(target_lang)
    report["font_compatibility"] = font_compatibility
    write_json(workspace_file(workspace_dir, "quality-report.json"), report)
    return report


def update_style_fonts(unpacked_dir: Path, target_lang: Optional[str]) -> Dict[str, object]:
    policy = get_target_font_policy(target_lang)
    summary = {
        "style_font_updates": 0,
        "updated_styles": [],
    }
    if policy is None:
        return summary

    styles_path = unpacked_dir / "word" / "styles.xml"
    if not styles_path.exists():
        return summary

    parser = etree.XMLParser(recover=False, huge_tree=True)
    tree = etree.parse(str(styles_path), parser=parser)
    root = tree.getroot()
    changed = False

    for style in root.findall("w:style", namespaces=DOCX_NAMESPACES):
        style_id, style_name = style_identity(style)
        r_pr = style.find("w:rPr", namespaces=DOCX_NAMESPACES)
        if r_pr is None:
            continue
        r_fonts = r_pr.find("w:rFonts", namespaces=DOCX_NAMESPACES)
        if r_fonts is None:
            continue
        east_asia_font = get_word_value(r_fonts, "eastAsia")
        if not font_is_unsuitable_for_target(east_asia_font, target_lang):
            continue
        set_word_value(r_fonts, "eastAsia", str(policy["primary"]))
        changed = True
        summary["style_font_updates"] = int(summary["style_font_updates"]) + 1
        summary["updated_styles"].append(
            {
                "style_id": style_id,
                "style_name": style_name,
                "new_eastAsia_font": str(policy["primary"]),
            }
        )

    if changed:
        styles_path.write_bytes(
            etree.tostring(
                tree,
                encoding="UTF-8",
                xml_declaration=True,
                standalone=False,
            )
        )

    summary["updated_styles"] = list(summary["updated_styles"])[:25]
    return summary


def extract_docx_to_workspace(input_docx: Path, workspace_dir: Path, include_comments: bool = True) -> Dict[str, object]:
    if not input_docx.exists():
        raise FileNotFoundError(f"Input DOCX not found: {input_docx}")
    if input_docx.suffix.lower() != ".docx":
        raise ValueError("Only .docx files are supported.")

    ensure_clean_dir(workspace_dir)
    unpacked_dir = workspace_dir / "unpacked"
    unpacked_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(input_docx, workspace_dir / "source.docx")
    with zipfile.ZipFile(input_docx, "r") as archive:
        archive.extractall(unpacked_dir)

    helper = DocxStructureHelper()
    segments_payload: List[Dict[str, object]] = []
    parts_payload: List[Dict[str, object]] = []

    for part_name, xml_path in iter_docx_parts(unpacked_dir, include_comments=include_comments):
        _tree, segments = helper.collect_segments_from_file(part_name, xml_path)
        parts_payload.append(
            {
                "part_name": part_name,
                "segment_count": len(segments),
            }
        )
        for segment in segments:
            segments_payload.append(
                {
                    "id": segment.segment_id,
                    "part": segment.part_name,
                    "index": segment.index,
                    "text": segment.text,
                }
            )

    manifest = {
        "source_docx": str(input_docx),
        "include_comments": include_comments,
        "segment_count": len(segments_payload),
        "parts": parts_payload,
    }
    write_json(workspace_file(workspace_dir, "manifest.json"), manifest)
    write_json(workspace_file(workspace_dir, "segments.json"), segments_payload)
    write_json(workspace_file(workspace_dir, "quality-report.json"), analyze_segments(segments_payload))
    write_json(workspace_file(workspace_dir, "translations.template.json"), [])
    return manifest


def build_batches_from_workspace(
    workspace_dir: Path,
    *,
    max_chars: int = 6000,
    max_items: int = 40,
) -> List[Dict[str, object]]:
    segments_path = workspace_file(workspace_dir, "segments.json")
    segments = read_json(segments_path)
    if not isinstance(segments, list):
        raise ValueError("segments.json must contain a list")

    batches: List[Dict[str, object]] = []
    current_items: List[Dict[str, object]] = []
    current_chars = 0
    batch_index = 0

    for item in segments:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text", ""))
        size = len(text)
        if current_items and (current_chars + size > max_chars or len(current_items) >= max_items):
            batches.append(
                {
                    "batch_id": batch_index,
                    "char_count": current_chars,
                    "items": current_items,
                }
            )
            batch_index += 1
            current_items = []
            current_chars = 0
        current_items.append(item)
        current_chars += size

    if current_items:
        batches.append(
            {
                "batch_id": batch_index,
                "char_count": current_chars,
                "items": current_items,
            }
        )

    write_json(workspace_file(workspace_dir, "batches.json"), batches)
    return batches


def load_translations_map(translations_path: Path) -> Dict[str, str]:
    payload = read_json(translations_path)
    if isinstance(payload, dict):
        return {str(key): str(value) for key, value in payload.items()}

    if not isinstance(payload, list):
        raise ValueError("translations must be either an object map or a list of {id, text}")

    mapping: Dict[str, str] = {}
    for item in payload:
        if not isinstance(item, dict):
            continue
        segment_id = item.get("id")
        if segment_id is None:
            continue
        mapping[str(segment_id)] = str(item.get("text", ""))
    return mapping


def apply_translations_from_workspace(
    workspace_dir: Path,
    translations_path: Path,
    output_docx: Path,
    *,
    target_lang: Optional[str] = None,
) -> Dict[str, object]:
    manifest = read_json(workspace_file(workspace_dir, "manifest.json"))
    if not isinstance(manifest, dict):
        raise ValueError("manifest.json is invalid")

    unpacked_dir = workspace_dir / "unpacked"
    translations_map = load_translations_map(translations_path)
    helper = DocxStructureHelper()
    normalized_target_lang = normalize_target_lang(target_lang)

    changed_segments = 0
    run_font_updates = 0
    missing_translations: List[str] = []

    include_comments = bool(manifest.get("include_comments", True))
    for part_name, xml_path in iter_docx_parts(unpacked_dir, include_comments=include_comments):
        tree, segments = helper.collect_segments_from_file(part_name, xml_path)
        if not segments:
            continue

        changed = False
        for segment in segments:
            translated_text = translations_map.get(segment.segment_id)
            if translated_text is None:
                missing_translations.append(segment.segment_id)
                continue
            translated_text = translated_text.strip()
            if not translated_text or translated_text == segment.text:
                continue
            apply_stats = helper.apply_translation(segment, translated_text, target_lang=normalized_target_lang)
            changed_segments += 1
            run_font_updates += int(apply_stats.get("run_font_updates", 0))
            changed = True

        if changed:
            xml_path.write_bytes(
                etree.tostring(
                    tree,
                    encoding="UTF-8",
                    xml_declaration=True,
                    standalone=False,
                )
            )

    if output_docx.suffix.lower() != ".docx":
        raise ValueError("Output file must end with .docx")
    output_docx.parent.mkdir(parents=True, exist_ok=True)
    style_summary = update_style_fonts(unpacked_dir, normalized_target_lang)
    package_unpacked_docx(unpacked_dir, output_docx)

    summary = {
        "output_docx": str(output_docx),
        "target_lang": normalized_target_lang,
        "changed_segments": changed_segments,
        "run_font_updates": run_font_updates,
        "style_font_updates": int(style_summary.get("style_font_updates", 0)),
        "updated_styles": style_summary.get("updated_styles", []),
        "missing_translation_count": len(missing_translations),
        "missing_translations": missing_translations[:50],
    }
    write_json(workspace_file(workspace_dir, "apply-result.json"), summary)
    return summary


def package_unpacked_docx(unpacked_dir: Path, output_docx: Path) -> None:
    with zipfile.ZipFile(output_docx, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for file_path in sorted(unpacked_dir.rglob("*")):
            if file_path.is_dir():
                continue
            archive.write(file_path, file_path.relative_to(unpacked_dir).as_posix())


def default_output_docx(workspace_dir: Path, suffix: str = "translated") -> Path:
    source_path = workspace_dir / "source.docx"
    if not source_path.exists():
        return workspace_dir / f"{suffix}.docx"
    return workspace_dir / f"{source_path.stem}_{suffix}{source_path.suffix}"


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Local DOCX skill helper. Extract text for the current model to translate, then apply translations back into a DOCX."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    extract_parser = subparsers.add_parser("extract", help="Extract translatable DOCX segments into a workspace")
    extract_parser.add_argument("input", help="Source .docx file")
    extract_parser.add_argument("--workspace", required=True, help="Workspace directory to create/reset")
    extract_parser.add_argument("--no-comments", action="store_true", help="Skip comments.xml")

    chunk_parser = subparsers.add_parser("chunk", help="Build translation batches from workspace segments")
    chunk_parser.add_argument("--workspace", required=True, help="Workspace directory created by extract")
    chunk_parser.add_argument("--max-chars", type=int, default=6000)
    chunk_parser.add_argument("--max-items", type=int, default=40)

    validate_parser = subparsers.add_parser("validate", help="Check extracted segments and font compatibility before translating")
    validate_parser.add_argument("--workspace", required=True, help="Workspace directory created by extract")
    validate_parser.add_argument("--target-lang", help="Target language code, e.g. zh-Hant, zh-Hans, ja, ko, en")

    apply_parser = subparsers.add_parser("apply", help="Apply translated text back into the DOCX workspace")
    apply_parser.add_argument("--workspace", required=True, help="Workspace directory created by extract")
    apply_parser.add_argument("--translations", required=True, help="JSON file containing translated segments")
    apply_parser.add_argument("--output", help="Output .docx path")
    apply_parser.add_argument("--target-lang", help="Target language code, e.g. zh-Hant, zh-Hans, ja, ko, en")

    inspect_parser = subparsers.add_parser("inspect", help="Show workspace summary")
    inspect_parser.add_argument("--workspace", required=True, help="Workspace directory created by extract")

    parser.add_argument("--verbose", action="store_true")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    if args.verbose:
        LOGGER.setLevel(logging.DEBUG)

    if args.command == "extract":
        manifest = extract_docx_to_workspace(
            Path(args.input).expanduser().resolve(),
            Path(args.workspace).expanduser().resolve(),
            include_comments=not args.no_comments,
        )
        quality_report = read_json(workspace_file(Path(args.workspace).expanduser().resolve(), "quality-report.json"))
        LOGGER.info("Workspace created with %s segments", manifest["segment_count"])
        if isinstance(quality_report, dict):
            LOGGER.info("Suspicious segments: %s", quality_report.get("suspicious_segment_count", 0))
        LOGGER.info("segments.json: %s", workspace_file(Path(args.workspace).expanduser().resolve(), "segments.json"))
        return 0

    if args.command == "chunk":
        workspace_dir = Path(args.workspace).expanduser().resolve()
        quality_report_path = workspace_file(workspace_dir, "quality-report.json")
        if quality_report_path.exists():
            quality_report = read_json(quality_report_path)
            if isinstance(quality_report, dict) and int(quality_report.get("suspicious_segment_count", 0)) > 0:
                LOGGER.warning(
                    "quality-report.json lists %s suspicious segments. Review them before translating.",
                    quality_report.get("suspicious_segment_count", 0),
                )
        batches = build_batches_from_workspace(
            workspace_dir,
            max_chars=args.max_chars,
            max_items=args.max_items,
        )
        LOGGER.info("Created %s batches", len(batches))
        LOGGER.info("batches.json: %s", workspace_file(Path(args.workspace).expanduser().resolve(), "batches.json"))
        return 0

    if args.command == "validate":
        workspace_dir = Path(args.workspace).expanduser().resolve()
        report = validate_workspace(workspace_dir, target_lang=args.target_lang)
        LOGGER.info(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    if args.command == "apply":
        workspace_dir = Path(args.workspace).expanduser().resolve()
        output_path = Path(args.output).expanduser().resolve() if args.output else default_output_docx(workspace_dir)
        summary = apply_translations_from_workspace(
            workspace_dir,
            Path(args.translations).expanduser().resolve(),
            output_path,
            target_lang=args.target_lang,
        )
        LOGGER.info("Output DOCX: %s", summary["output_docx"])
        LOGGER.info("Changed segments: %s", summary["changed_segments"])
        LOGGER.info("Run font updates: %s", summary["run_font_updates"])
        LOGGER.info("Style font updates: %s", summary["style_font_updates"])
        LOGGER.info("Missing translations: %s", summary["missing_translation_count"])
        return 0

    if args.command == "inspect":
        workspace_dir = Path(args.workspace).expanduser().resolve()
        manifest = read_json(workspace_file(workspace_dir, "manifest.json"))
        LOGGER.info(json.dumps(manifest, ensure_ascii=False, indent=2))
        return 0

    parser.error("Unknown command")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
