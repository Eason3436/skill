# Workspace Format

The skill workspace is a normal directory created by:

```powershell
python "<skill-dir>\scripts\translate_docx.py" extract "<input.docx>" --workspace "<workspace>"
```

## Files

### `manifest.json`

Summary of the extracted DOCX.

Example:

```json
{
  "source_docx": "C:/docs/report.docx",
  "include_comments": true,
  "segment_count": 148,
  "parts": [
    { "part_name": "word/document.xml", "segment_count": 120 }
  ]
}
```

### `segments.json`

Flat list of all translatable segments.

Example:

```json
[
  {
    "id": "word/document.xml::0",
    "part": "word/document.xml",
    "index": 0,
    "text": "Original text"
  }
]
```

### `batches.json`

List of translation batches produced by `chunk`.

Example:

```json
[
  {
    "batch_id": 0,
    "char_count": 4210,
    "items": [
      {
        "id": "word/document.xml::0",
        "part": "word/document.xml",
        "index": 0,
        "text": "Original text"
      }
    ]
  }
]
```

### `translations.json`

You create this file after translating.

Accepted formats:

1. Object map from `id` to translated string.
2. List of objects with `id` and `text`.

### `apply-result.json`

Created by the `apply` command. Summarizes how many segments changed, how many run/style font repairs were made, and how many translations were missing.

### `quality-report.json`

Created by `extract` and refreshed by `validate`.

Example:

```json
{
  "segment_count": 148,
  "max_segment_chars": 312,
  "warning_chars": 800,
  "suspicious_segment_count": 0,
  "suspicious_segments": [],
  "target_lang": "zh-Hant",
  "font_compatibility": {
    "target_lang": "zh-Hant",
    "cjk_target": true,
    "preferred_eastAsia_font": "Microsoft JhengHei",
    "suspicious_run_font_count": 0,
    "suspicious_style_font_count": 0
  }
}
```

Pass `--target-lang` to `validate` when the target language is `zh-Hant`, `zh-Hans`, `ja`, or `ko`. That enables font compatibility checks before translation.

## Operational Notes

- Keep every `id` unchanged.
- The script rebuilds the DOCX from the workspace, so do not edit files inside `unpacked/` manually unless you know what you are doing.
- If you re-run `extract`, the workspace is reset.
- Run `extract` and `chunk` sequentially. `chunk` depends on a completed `segments.json`.
- Run `validate` after `extract` and before translating.
- If `quality-report.json` shows suspicious merged segments, stop and fix extraction first.
- For CJK output languages, pass `--target-lang` to both `validate` and `apply`.
- Run-level font repair only touches translated runs that contain CJK text and have missing or obviously unsuitable `eastAsia` fonts.
- Style-level font repair only changes styles whose `eastAsia` font is explicitly incompatible with the target CJK language.
- Workspace JSON files are written as UTF-8 with BOM for better Windows compatibility.
